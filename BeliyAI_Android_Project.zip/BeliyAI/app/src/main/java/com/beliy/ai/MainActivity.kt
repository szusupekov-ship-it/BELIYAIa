package com.beliy.ai

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BeliyAIApp(this) }
    }
}

@Composable
fun BeliyAIApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("beliy_ai", Context.MODE_PRIVATE) }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "gpt-4o-mini") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Добавь API-ключ в настройках для подключения ИИ.") }
    val messages = remember { mutableStateListOf(ChatMessage("Привет! Я Beliy AI. Подключи API в настройках и напиши сообщение.", false)) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val bg = Color(0xFF0B1020)
    val panel = Color(0xFF151D32)
    val accent = Color(0xFF71D7CE)

    MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = bg, surface = panel)) {
        Column(Modifier.fillMaxSize().background(bg).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("BELIY AI", color = accent, fontSize = 23.sp)
                    Text("Персональный ИИ-ассистент", color = Color.LightGray, fontSize = 12.sp)
                }
                TextButton(onClick = { showSettings = true }) { Text("НАСТРОЙКИ") }
            }
            Spacer(Modifier.height(12.dp))
            Surface(color = panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(state = listState, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages) { m ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                            Surface(color = if (m.fromUser) Color(0xFF244B58) else Color(0xFF263047), shape = RoundedCornerShape(15.dp), modifier = Modifier.widthIn(max = 300.dp)) {
                                Text(m.text, Modifier.padding(12.dp), color = Color.White)
                            }
                        }
                    }
                    if (busy) item { Text("Beliy AI печатает…", color = accent) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(status, color = Color.LightGray, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Сообщение…") }, maxLines = 4, shape = RoundedCornerShape(16.dp))
                Spacer(Modifier.width(8.dp))
                Button(enabled = input.isNotBlank() && !busy, onClick = {
                    val prompt = input.trim()
                    input = ""
                    messages.add(ChatMessage(prompt, true))
                    busy = true
                    scope.launch {
                        val answer = requestAI(endpoint, apiKey, model, messages.toList())
                        messages.add(ChatMessage(answer, false))
                        status = if (answer.startsWith("Ошибка:")) "Проверь настройки подключения." else "Ответ получен."
                        busy = false
                        listState.animateScrollToItem(messages.size - 1)
                    }
                }) { Text("➤") }
            }
        }
        if (showSettings) {
            AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Подключение ИИ") },
                text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Нужен API-ключ провайдера. Не публикуй его в GitHub.")
                    OutlinedTextField(endpoint, { endpoint = it }, label = { Text("API endpoint") }, singleLine = true)
                    OutlinedTextField(model, { model = it }, label = { Text("Модель") }, singleLine = true)
                    OutlinedTextField(apiKey, { apiKey = it }, label = { Text("API key") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                } },
                confirmButton = { TextButton(onClick = {
                    prefs.edit().putString("endpoint", endpoint.trim()).putString("model", model.trim()).putString("api_key", apiKey.trim()).apply()
                    status = if (apiKey.isBlank()) "API-ключ не задан." else "Настройки сохранены."
                    showSettings = false
                }) { Text("СОХРАНИТЬ") } },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("ОТМЕНА") } }
            )
        }
    }
}

private suspend fun requestAI(endpoint: String, apiKey: String, model: String, history: List<ChatMessage>): String =
    withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext "Ошибка: сначала добавь API-ключ в настройках."
        if (!endpoint.startsWith("https://")) return@withContext "Ошибка: endpoint должен начинаться с https://."
        try {
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer $apiKey")
            }
            val arr = JSONArray()
            arr.put(JSONObject().put("role", "system").put("content", "Ты — Beliy AI, полезный русскоязычный ИИ-ассистент. Отвечай ясно и безопасно."))
            history.takeLast(20).forEach { arr.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text)) }
            val body = JSONObject().put("model", model).put("messages", arr).put("temperature", 0.7)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream.bufferedReader().use { it.readText() }
            conn.disconnect()
            if (code !in 200..299) "Ошибка: HTTP $code — $raw"
            else JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        } catch (e: Exception) { "Ошибка: ${e.message ?: "не удалось подключиться"}" }
    }
