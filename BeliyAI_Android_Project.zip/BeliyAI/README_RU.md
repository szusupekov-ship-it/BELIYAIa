# Beliy AI — Android MVP

Kotlin + Jetpack Compose. Чат с настройками API endpoint, модели и API-ключа. Совместим с API, поддерживающим формат OpenAI Chat Completions.

## Важно
Приложение не содержит встроенный бесплатный ИИ: для ответов нужен API-ключ и доступ к провайдеру. Ключ хранится локально на устройстве, но не загружай его в GitHub и не передавай APK с ключом другим людям. Для публичного приложения лучше использовать собственный сервер-посредник.

## Сборка
GitHub Actions собирает debug APK при push в main или вручную через Actions → Build Beliy AI APK → Run workflow.
